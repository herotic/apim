export const environment = {
  production: true,
  baseHref: '/api-spec-converter',
};
