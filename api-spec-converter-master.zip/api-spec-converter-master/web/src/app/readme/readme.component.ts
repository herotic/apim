import {Component} from '@angular/core';

@Component({
    selector: 'readme',
    templateUrl: '../../../README.md',
})
export class ReadmeComponent {
  constructor() {}
}
