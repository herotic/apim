# 2016-07-11
## Released 2.0.0 to npm
- Support for promises
- Support of API blueprint in browser build

## Release 2.0.1 to npm and bower
- Update README to describe support for promises

# 2017-07-17
## Release 2.3.0 to npm
- Support for YAML output
