#!/bin/bash

set -e
if (( ${BASH_VERSION%%.*} < 4 )); then
	echo "Your version of bash (${BASH_VERSION}) is too old; please upgrade"
	exit 1
fi

if [[ $EUID != 0 ]]; then
	echo "You need to be root to perform this command."
	exit 1
fi

if [[ $(command -v docker) == "" ]]; then
	echo "CA API Developer Portal requires docker to run. Please install docker and try again."
	exit 1
fi
if [[ $(systemctl is-active docker) != "active" ]] || [[ $(systemctl is-enabled docker) != "enabled" ]]; then
	echo "CA API Developer Portal requires docker service to be enabled and active. Please enable and activate the docker service and try again."
	exit 1
fi
DOCKER_VERSION=17.06
v=$(docker --version | grep -oE '[0-9]+\.[0-9.]+' | head -n1)
if ! echo -e "${DOCKER_VERSION}\n${v}" | sort -cV 2>/dev/null; then
	>&2 echo "docker is too old (version ${v}), upgrade to at least version ${DOCKER_VERSION}."
	exit 1
fi

declare -A k2v
declare -a ERRORS
declare -a env_skip

defaults=("example.com" "" "noreply@mail.example.com" "y")
desc=("Portal domain" "Path to license file" "Enroll notification email address" "Analytics enabled")
conf=(PORTAL_DOMAIN PORTAL_LICENSE_FILENAME PORTAL_ENROLL_NOTIFICATION_EMAIL PORTAL_ENABLE_ANALYTICS)
constraints=(
	"^[a-zA-Z0-9][a-zA-Z0-9.-]+[a-zA-Z0-9]$"
	"license"
	"^.+@[^\.].*\.[a-z]{2,}$"
	"^(y|Y|n|N)$")
config=config.sh
EMPTY="<empty>"

function setup {
	if [[ $(basename "$0") != "$config" ]]; then
		return
	fi
	C="$1"
	echo -e "\nAPIM Portal configuration\n"
	if [[ -e "$C" ]]; then
		echo "Portal has been configured already; current settings are: "
		s_current "$C"
		A=$(prompt "Do you want to change portal settings? [y/N]" "n")
		if [[ ! ${A,,} =~ ^(yes|y)$ ]]; then
			echo -e "\nDone."
			exit 0
		fi
		cp "$C" "${C}.$(date +'%F')"
	fi
	while true; do
		s_conf
		f="$retval"
		s_current "$f"
		A=$(prompt "Do you want to keep these settings? [Y/n]" "y")
		if [[ ${A,,} =~ ^(yes|y)$ ]]; then
			mv "$f" "$C"
			echo -e "\nDone."
			deps
			exit 0
		fi
		rm "$f"
	done
}

function remove_service {
	if [ -f /etc/systemd/system/apim-portal.service ]; then
		echo -e "\nDeleting apim-portal service.\nTo start the portal stack, run portal.sh from the installation directory.\nsystemctl start apim-portal is no longer available.\n"
		rm /etc/systemd/system/apim-portal.service
	fi
}

function deps {
	remove_service
	util/configure-node.sh -n manager
	check_hw
	err_count=${#ERRORS[@]}
	if [[ $err_count -gt 0 ]]; then
		suf=""
		if [[ $err_count -gt 1 ]]; then suf="s"; fi
		echo "Please fix the following error${suf}:"
		for e in "${ERRORS[@]}"; do
			echo -e "   -\t$e"
		done
		exit 1
	fi
}

function s_conf {
	for i in "${!conf[@]}"; do
		while true; do
			default="${!conf[i]}"
			default=${default:-"${defaults[i]}"}
			A=$(prompt "${desc[i]} (${conf[i]}) [${default}]" "${default}")
			case "${constraints[i]}" in
			license)
				if [[ -e ${A} ]]; then
					declare ${conf[i]}=${A}
					break
				fi
				echo -e "File '${A}' not found \n"
				continue
				;;
			*)
				if [[ ${A} =~ ${constraints[i]} ]]; then
					declare ${conf[i]}=${A}
					break
				fi
				;;
			esac
			echo -e "Invalid value for ${desc[i],,}: '${A}'\n"
		done
	done
	tmp=$(mktemp)
	if [[ ! -z $PORTAL_TENANT_ID ]]; then
		echo "PORTAL_TENANT_ID=${PORTAL_TENANT_ID,,}" >> "$tmp"
	fi
	for i in "${conf[@]}"; do
		echo "${i}=${!i}" >> "$tmp"
	done
	retval=$tmp
}

function s_current {
	source "$1"
	if [[ -z $PORTAL_DOMAIN ]]; then
		PORTAL_DOMAIN=$PORTAL_SUBDOMAIN
	fi
	m=${#conf[0]}
	for i in "${conf[@]}"; do
		if [[ $m -lt ${#i} ]]; then
			m=${#i}
		fi
	done
	m=$((m + 2))
	e=""
	z=""
	for i in "${conf[@]}"; do
		e="${e}\n%${m}s:\t%s"
		z="$z ${i} ${!i} "
	done
	printf $e'\n\n' $z
}

function prompt {
	read -ep "$1: " a
	a=${a:-$2}
	echo "$a"
}

function check_hw {
	cpu=$(docker info --format '{{json .NCPU}}')
	mem=$(docker info --format '{{json .MemTotal}}')
	max=$((mem * 85 / 100 / 1024 / 1024))
	if [ "$cpu" -lt 4 ]; then
		report_error "Insufficent number of CPU cores ($cpu), at least 4 cores required."
	fi
	if [ $max -lt 10440 ]; then
		report_error "Insufficent memory (${max}MB), at least 12GB required for a demo instance."
	elif [ $max -lt 27100 ]; then
		echo "WARNING: less than 32GB of RAM available; please increase the amount of system memory for production deployments."
	fi
	add_value sys.MEM_XL "$((max * 1651 / 10000))M"
	add_value sys.MEM_L "$((max * 1445 / 10000))M"
	add_value sys.MEM_M "$((max * 825 / 10000))M"
	add_value sys.MEM_S "$((max * 412 / 10000))M"
	add_value sys.MEM_XS "$((max * 206 / 10000))M"

	add_value sys.RES_XL "$((max * 1651 / 12500))M"
	add_value sys.RES_L "$((max * 1445 / 12500))M"
	add_value sys.RES_M "$((max * 825 / 12500))M"
	add_value sys.RES_S "$((max * 412 / 12500))M"
	add_value sys.RES_XS "$((max * 206 / 12500))M"
}

function add_value {
	k="${1//^[^A-Z]+//}"
	trim "$k"
	k="$retval"
	trim "$2"
	v="$retval"
	trim "$3"
	z="$retval"
	k2v["$k"]="$v"
	if [[ ! -z "$v" ]]; then
		if [[ ! -z "$z" ]]; then
			k2v["$v"]="$z"
		fi
	fi
}

function report_error {
	if [[ ! " ${ERRORS[@]} " == " ${1} " ]]; then
		ERRORS+=("$1")
	fi
}

function smtp_params {
	if [[ ! -z ${PORTAL_SMTP_HOST} ]]; then
		env_skip+=("env-smtp")
		add_value "smtp.HOST" "$PORTAL_SMTP_HOST"
		add_value "smtp.PORT" "$PORTAL_SMTP_PORT"
		add_value "smtp.USERNAME" "$PORTAL_SMTP_USERNAME"
		add_value "smtp.PASSWORD" "$PORTAL_SMTP_PASSWORD"
		if [[ -z "$PORTAL_SMTP_SSL_CERT" ]]; then
			add_value "smtp.REQUIRE_SSL" false
			add_value "smtp.POSTFIX_CERT" notinstalled
			return;
		fi
		add_value "smtp.REQUIRE_SSL" true
		read_certificate "PORTAL_SMTP_SSL_CERT" "$PORTAL_SMTP_SSL_CERT"
		add_value "smtp.POSTFIX_CERT" "$retval"
		return
	fi
	add_value "smtp.REQUIRE_SSL" true
	add_value "smtp.HOST" "smtp"
	add_value "smtp.PORT" 25
	add_value "smtp.USERNAME" "superuser"
	add_value "smtp.PASSWORD" "supersecret"
}

function db_params {
	var=PORTAL_DATABASE_TYPE
	db_type=$(gvalue ${var})
	case "$db_type" in
	postgresql|postgres)
		add_value "db.DATABASE_TYPE" "postgresql"
		add_value "db.DATABASE_USERNAME" "${PORTAL_DATABASE_USERNAME:-admin}"
		add_value "db.DATABASE_PASSWORD" "${PORTAL_DATABASE_PASSWORD:-7layer}"
		add_value "db.DATABASE_HOST" "${PORTAL_DATABASE_HOST:-portaldb}"
		add_value "db.DATABASE_PORT" "${PORTAL_DATABASE_PORT:-5432}"
		for n in HOST USERNAME PASSWORD PORT; do
			add_value "db.POSTGRES_${n}" "$(gvalue "db.DATABASE_${n}")"
		done
		;;
	mysql)
		add_value "db.DATABASE_TYPE" "mysql"
		for n in USERNAME PASSWORD HOST PORT; do
			tmp=PORTAL_DATABASE_$n
			tmp=${!tmp}
			if [[ -z $tmp ]]; then
				report_error "PORTAL_DATABASE_$n needs to be specified"
			fi
			add_value "db.DATABASE_${n}" "$tmp"
		done
		add_value "db.POSTGRES_HOST" portaldb
		add_value "db.POSTGRES_USERNAME" admin
		add_value "db.POSTGRES_PASSWORD" 7layer
		add_value "db.POSTGRES_PORT" 5432
		if [[ ! $AE == y ]]; then
			for skip in "env-postgres-master" "env-postgres-slave" "env-volumes"; do
				env_skip+=(${skip})
			done
		fi
		;;
	*)
		report_error "$var '$db_type' not yet supported"
	esac
	add_value "db.JARVIS_HOSTNAME" "$(gvalue db.POSTGRES_HOST)"
	add_value "db.JARVIS_USERNAME" "$(gvalue db.POSTGRES_USERNAME)"
	add_value "db.JARVIS_PORTNO" "$(gvalue db.POSTGRES_PORT)"
	add_value "db.JARVIS_USERPWD" "$(gvalue db.POSTGRES_PASSWORD)"
	add_value "db.JARVIS_DBNAME" "lddsdb"
}

function get_value {
	local f="$1"
	local -r n=$(echo "$2" | cut -d. -f2)
	local v=""
	if [[ ${n} == PORTAL_* ]]; then
		v="${!n}"
	fi
	case "$f" in
	read_license)
		if [[ -z "$v" ]]; then
			report_error "Variable '$n' is not set"
			retval=""
			return
		fi
		read_license "$n" "$v"
		v="$retval"
		;;
	*)
		if [[ $3 =~ internal_|random_pass|key_pass ]]; then
			generate_value "$3" "$4"
			v="$retval"
		fi
	esac
	retval="$v"
}

function key_password {
	echo "$1" | grep -Eo '\.[^_]+' | sha1sum | head -c18 | base64
}

function generate_value {
	local -r f=$(echo "$1" | grep -oP '(?<=^{{ )[^(]+')
	local var="$2"
	v=""
	case "$f" in
	key_pass)
		z=$(echo $var | sed 's/^[^.]*\.//')
		z=PORTAL_${z}
		if [[ ! -z ${!z} ]]; then
			retval=${!z}
			return
		fi
		v=$(key_password "$var")
		;;
	random_pass)
		v=$(openssl rand -base64 18)
		;;
	internal_cert | internal_p8_key | internal_p12_key | internal_smtp_cert)
		filename=$(echo "$1" | grep -oP "(?<=\(')[^']+")
		host=$(echo "$1" | grep -oP "(?<=${filename}', ')[^']+")
		z=$(echo $var | sed 's/^[^.]*\.//')
		z=PORTAL_${z}
		if [[ ! -z ${!z} ]]; then
			filename=${!z}
			read_certificate "$z" "$filename"
			retval="$retval"
			return
		fi
		filename="$CERTS_DIR/$(basename "$filename")"
		pass=$(key_password "$var")
		host=$(gvalue "$host")
		read_certificate "$var" "$filename" 1
		if [[ -z "$retval" ]]; then
			gen_certificate "$filename" "$pass" "$host" "$f"
			if [[ $retval -gt 0 ]]; then
				retval=""
				return
			fi
			read_certificate "$var" "$filename"
		fi
		v="$retval"
		;;
	*)
		report_error "Function '$f' not implemented"
	esac
	retval="$v"
}

function file_exists {
	retval=0
	local optional=${3:-0}
	if [[ ! -e "$1" ]]; then
		if [[ $optional -eq 0 ]]; then
			report_error "File '$1' ($2) does not exist"
		fi
		retval=1
	fi
}

function trim {
	local var="$1"
	var="${var#"${var%%[![:space:]]*}"}"
	var="${var%"${var##*[![:space:]]}"}"
	retval="$var"
}

function read_license {
	filename="$2"
	file_exists "$filename" "$1"
	if [[ $retval -gt 0 ]]; then
		retval=""
		return
	fi
	retval=""
	local -r valid_from=$(grep -oP '(?<=valid>)[^<]+' "$filename")
	local -r valid_to=$(grep -oP '(?<=expires>)[^<]+' "$filename")
	if [[ -z ${valid_from} || -z ${valid_to} ]]; then
		report_error "Could not determine license validity for '$filename'"
		return
	fi
	local -r dt_now=$(date +%s)
	local -r dt_from=$(date -d "$valid_from" +%s)
	local -r dt_to=$(date -d "$valid_to" +%s)
	if [[ $dt_now -gt $dt_to ]]; then
		report_error "License '$filename' has expired"
		return
	fi
	if [[ $dt_now -lt $dt_from ]]; then
		report_error "License '$filename' is not yet active"
		return
	fi
	retval=$(gzip -c "$filename" | base64 -w0)
}

function read_certificate {
	varname="$1"
	filename="$2"
	optional="$3"
	if [[ ! $filename == /* ]]; then
		filename="$CERTS_DIR/$(basename "$filename")"
	fi
	file_exists "$filename" "$varname" "$optional"
	if [[ $retval -gt 0 ]]; then
		retval=""
		return
	fi
	retval=$(base64 -w0 "$filename")
}

function gen_certificate {
	local key_name="$1"
	key_name=$(echo "$key_name" | cut -d '.' -f -1)
	local pass="$2"
	local host="$3"
	local -r dir="$(dirname "$key_name")"
	if [ ! -d "$dir" ]; then
		report_error "Directory '$dir' does not exist"
		retval=1
		return
	fi
	echo "Generating key/cert for $host"
	if [[ ${4} == "internal_smtp_cert" ]]; then
		openssl genrsa -out "${key_name}.key" 2048 &> /dev/null
		openssl req -new -x509 -key "${key_name}.key" -nodes \
			-subj "/CN=${host}" \
			-out "${key_name}.crt" -days $((365 * 3)) &> /dev/null
		openssl req -new -nodes -x509 -extensions v3_ca -keyout cakey.pem \
			-subj "/CN=${host}" \
			-out "${key_name}.pem" -days $((365 * 3)) &> /dev/null
		rm cakey.pem
	else
		openssl genrsa -des3 -out "${key_name}.key" -passout pass:"$pass" 2048 &> /dev/null
		openssl req -new -x509 -key "${key_name}.key" \
			-subj "/CN=${host}" \
			-out "${key_name}.crt" -passin pass:"$pass" -days $((365 * 3)) &> /dev/null
		openssl pkcs12 -export -inkey "${key_name}.key" -in "${key_name}.crt" \
			-out "${key_name}.p12" -passin pass:"$pass" -passout pass:"$pass" &> /dev/null
		openssl pkcs8 -in "${key_name}.key" -topk8 -outform der -out "${key_name}.p8" \
			-v1 PBE-SHA1-3DES -passin pass:"$pass" -passout pass:"$pass" &> /dev/null
		if [[ ${key_name} == *apim ]]; then
			openssl pkcs12 -in "${key_name}.p12" -out "${key_name}.pem" -nodes \
				-passin pass:"$pass" &> /dev/null
		fi
		rm "${key_name}.key"
		if [[ ${1} == *p12 ]]; then
			rm -f "${key_name}".{p8,crt}
		fi
	fi
	chmod 600 "${key_name}".*
	retval=0
}

function read_values {
	local prefix="$2"
	while read line; do
		v=$(echo "$line" | grep -oE "^[^=]+" | sed 's/^[^a-zA-Z]*//')
		k=$(echo "$line" | grep -oP "(?<={{ )[^}]+" || true)
		key=$(echo "$line" | grep -oP "(?<==).*$" || true)
		var="${prefix}.${v}"
		if [ "${k2v["$var"]+_}" ]; then
			continue
		fi
		x=$(echo "$k" | sed 's/ *| */ /')
		f=$(echo "$x" | cut -s -d ' ' -f2)
		n=$(echo "$x" | cut -d ' ' -f1)
		get_value "$f" "$n" "$key" "$var"
		if [[ -z "$k" ]]; then
			k="$key"
		fi
		add_value "$var" "$k" "$retval"
	done < <(cat "$1")
}

function gvalue {
	key="$1"
	z="$key"
	while true; do
		if [[ -z "$z" ]]; then
			break
		fi
		key="$z"
		z=${k2v["$key"]}
	done
	if [[ ${key} == user.* ]]; then
		key=${key#*.}
		key=${!key}
	fi
	if [[ ${key} == "$EMPTY" ]]; then
		key=""
	fi
	echo ${key}
}

function set_values {
	local lf=$'\n'
	local exp=""
	for var in "${!k2v[@]}"; do
		key=$(gvalue "$var")
		exp=$"${exp} ${lf}s~{{[[:space:]]*${var}[[:space:]][^}]*}}~${key}~g"
	done
	exp=$"${exp} ${lf}s|{{[^}]*}}||g"
	if [[ ! $AE == y ]]; then
		exp=$"${exp} ${lf}/^JARVIS_/d"
		exp=$"${exp} ${lf}/^ES_/d"
	fi
	exptmp=$(mktemp)
	echo "$exp" > "$exptmp"
	for i in ${ENV_PATH}/*; do
		j=$(basename "$i")
		sed -f "$exptmp" "$i" > "$RUN_PATH/$j"
	done
	rm "$exptmp"
}

function single {
	path_yml=${RUN_PATH}/docker-compose.yml
	for skip in "${env_skip[@]}"; do
		sed -i "/${skip}/d" "$path_yml"
	done
	while IFS= read -r env; do
		path="$RUN_PATH/$env"
		i=$(grep "$env" "$path_yml" | grep -oE "^[^e]*")
		sed -i "s/^/${i}/" "$path"
		sed -i -e "/^.*${env}$/r ${path}" -e "/^.*${env}$/d" "$path_yml"
	done < <(grep -o "env-.*$" "$path_yml")
	YML=$(cat "$path_yml")
	JARVIS=$(cat "$RUN_PATH/jarvis.yml")
	JARVIS_HA=$(cat "$RUN_PATH/jarvis-ha.yml")
	if [[ ${1} == "keep" ]]; then
		cp "$path_yml" .
		if [[ $AE == y ]]; then
			cp "${RUN_PATH}"/jarvis*.yml .
		fi
	fi
}

function jarvis-ha {
	local labels=("zookeeper2" "zookeeper3" "kafka2" "kafka3")
	local counts=(-1 -1 -1 -1)
	local ha=0
	for node in $(docker node ls -q); do
	        for i in "${!labels[@]}"; do
	                counts[i]=$((counts[i] + $(docker node inspect "$node" | grep "${labels[i]}" | grep -c '\"true\"' || true)))
	        done
	done
	for i in "${!counts[@]}"; do
		if [ ${counts[i]} -lt 0 ]; then
			ha=1
			break
		fi
	        ha=$((ha + counts[i]))
	done
	if [ $ha -ne 0 ]; then
		echo "${JARVIS}"
	else
		echo "${JARVIS_HA}"
	fi
}

function config {
	tag_line=$(grep -n '^UUE:$' "$0" | cut -d ':' -f 1)
	if [[ -z $tag_line ]]; then
		return
	fi
	DOCKER_CONFIG=$(mktemp -d)
	TEMP_CONFIG=${DOCKER_CONFIG}
	tail -n +$((tag_line + 1)) "$0" | base64 -d | tar xzC "$DOCKER_CONFIG"
}

function cleanup {
	rm -rf "$TEMP_CONFIG" "$RUN_PATH"
}

USER_CONFIG=${PORTAL_USER_CONFIG:-conf/portal.conf}

setup "$USER_CONFIG"

if [[ ! -e ${USER_CONFIG} ]]; then
	echo "Please configure portal by running ${config} first"
	exit 1
fi

deps
config

ENV_PATH=${DOCKER_CONFIG:-config}
RUN_PATH=$(mktemp -d)
source "$USER_CONFIG"
if [[ -z ${PORTAL_DOMAIN} ]]; then
	PORTAL_DOMAIN=$PORTAL_SUBDOMAIN
fi
AE=${PORTAL_ENABLE_ANALYTICS:-y}
AE=${AE,,}
PORTAL_TENANT_ID=${PORTAL_TENANT_ID:-apim}
PORTAL_SSO_DEBUG=${PORTAL_SSO_DEBUG:-false}
CERTS_DIR=${PORTAL_CERTS_DIR:-certs}
if [[ -z ${PORTAL_DATABASE_HOST} ]]; then
	PORTAL_DATABASE_TYPE=postgres
fi
add_value PORTAL_DATABASE_TYPE "${PORTAL_DATABASE_TYPE:-mysql}"
db_params
smtp_params
add_value gen.PORTAL_VERSION "4.2.9.3"
add_value gen.PSSG_HOSTNAME pssg
add_value gen.PUBLIC_HOST "$(gvalue user.PORTAL_TENANT_ID)-ssg.$(gvalue user.PORTAL_DOMAIN)"
add_value gen.WILDCARD_DOMAIN "*.$(gvalue user.PORTAL_DOMAIN)"

for f in ${ENV_PATH}/env-*; do
	read_values "$f" "$(basename "$f" | sed 's/^env-//')"
done

for i in REGISTRY USERNAME PASSWORD; do
	read -r "DOCKER_$i" <<< $(gvalue "docker.DOCKER_$i")
	read -r "JARVIS_$i" <<< $(gvalue "docker.JARVIS_$i")
done

err_count=${#ERRORS[@]}
if [[ $err_count -gt 0 ]]; then
	suf=""
	if [[ $err_count -gt 1 ]]; then suf="s"; fi
	echo "Please fix the following error${suf}:"
	for e in "${ERRORS[@]}"; do
		echo -e "   -\t$e"
	done
	cleanup
	exit 1
fi
set_values
single "$1"
cleanup

docker login -u "${DOCKER_USERNAME}" --password "${DOCKER_PASSWORD}" "${DOCKER_REGISTRY}" &> /dev/null
docker login -u "${JARVIS_USERNAME}" --password "${JARVIS_PASSWORD}" "${JARVIS_REGISTRY}" &> /dev/null

if [[ ! "${AE}" == y ]]; then
	JARVIS=""
fi
IMAGES=$(echo -e "${JARVIS}\n${YML}" | grep -o "image:.*$" | sed 's/^image: //' | sort -u)
for i in $IMAGES; do
	>&2 docker pull "${i}"
done
NODE=$(docker node ls -q 2> /dev/null || true)
if [[ -z $NODE ]]; then
	docker swarm init > /dev/null
fi
LABELS=""
for l in portal portal.persist postgresql.master postgresql.slave; do
	LABELS="${LABELS} --label-add $l=true "
done
if [[ "${AE}" == y ]]; then
	for l in jarvis.elasticsearch jarvis.kafka1 jarvis.ldds jarvis.services \
						jarvis.utilities jarvis.zookeeper1; do
		LABELS="${LABELS} --label-add $l=true "
	done
fi
for NODE in $(docker node ls -qf role=manager); do
	docker node update ${LABELS} "${NODE}" > /dev/null
done
if [[ "${AE}" == y ]]; then
	tmpfile=$(mktemp)
	jarvis-ha > "$tmpfile"
	docker stack deploy --with-registry-auth --compose-file "$tmpfile" portal
	rm "$tmpfile"
fi
tmpfile=$(mktemp)
echo "${YML}" > "$tmpfile"
docker stack deploy --with-registry-auth --compose-file "$tmpfile" portal
rm "$tmpfile"
echo "

APIM Portal services are currently being orchestrated in the background.
To check the status of the services please run ./status.sh
After all services are up and running, please navigate to ${PORTAL_TENANT_ID}.${PORTAL_DOMAIN}

For additional information on advanced setup of APIM Portal please check documentation at
https://docops.ca.com/ca-api-developer-portal-enhanced-experience/4-2/en

"
exit 0
# generated 2018-10-17 11:05:04
UUE:
H4sIANB5x1sCA+09a3PiuLLzOb+COl/YuTUGPyAQqlx3HXASNoA5tjOPrVPlcsBJOAHM2s7s5u7u
f7+Sn7IkgyGEhFlppmaw1GrJUqvV3Wq1a/WpO3l0PG7iLlau79SeF/MPe048SKenDfi/0Gry6P/w
pyQJ/Afw76lw2mq0RJAvNAVe+FDhPxwgPfmB7VUqHwLHXkxmwXMR3KbyI03fHc+fuctOpSrVpOrJ
0gl+d71Hv3NSqayebuezSfjLm323A6dz4jve99nECYud5XcOUExw7zk+t7D9wPHwXH9uf3fiTH8R
rMBPe2nPn4PZBBQCXI4HMVUqs4V973Qq9mq2ALW9wJ7XVvbkEWT6tYldA7RZR8rqBJJGTaydhZhA
UzPPXS6cZRChrnBh83iVsAx92wg0ftPweeqs5u5zUrZwp6CH93P31p7HWau5PXGQlkCauEs/8OzZ
MvCzTIh4CarX5vatM/dr0VtUZLkSeE9ODPa0moKGLYDgbnaf1V3Znj2fO/OZv+hUhDR76sztZ5DB
+2nWnT2bP3mOZU+CcEJX9pOfIAeT4T558cRFaT5bzPKdXDgL1wNIRbHRGKb5oCoYMBvipEILrbPm
MGsGLKbAWrmAcJ5zozKdRb1yl1zcUVA6nfkrO5g87EgGSPV1BBBTQAadzK6znPoW6FQ2+yFeDlR1
PEAJ6fBxYZcyMN+/Tx88+/Z2Fix+KyKocBFR6Qu2FkPGcP6DM+1U2nwMDsby3gk6lTM+zYqo8AEs
MLLeWaMh4TWzrHU1yYrtwor7XxWeO3fgYliANXofz857Wg8CL26xHpqCuMVysJfPkCkC6tppBcyW
kM/6Zcg/pWAa4QfO0l4G3Mpzv8/gdpDOwkvo+5/KPyW+JZanFxR6W/5J8KudiIjEUoKc6KySylS3
4ZaMfAAzPtuGfJpn0gvJB7y4/RLCCeuXJxkIzojl+IgFzMxuVAIrliGPZOrZJvOuNhnfne8mnocV
N0z8yDAso3du3Riq1VW6V6q8dNPCX5TPiqWNTUPmvi58IFgtKuDHH/DH1izBA0+zie1n8/Mywqit
oOLsB++WQARBFMoTSPvsdFf6IGXHnagFRwNEWy42N5ThHgUS7MY9hi7HvCVlMYpK9v2d6GgB9CFQ
xt167mPOMAA12KW9AKhyckUhRe0gd/xjSKF5ypenhEajvSsl2E/BAxg8MKaBu6OpMIehhJ0Qhd/M
QphU+oacAs7Xd3f+BJb8yQeWdkq1Os06fsjzH17ghSZ+/tNotNj5zyGSAuRvY2B1Vd2U//wzZLg1
JK/y998n8eO1+g2HAFl5AGusGAYFKsyHoKph3egD+SEIVp16HbAgH1KdY3uTh86ZyPN1CNEd3Bim
qsv/tYH453PRASUsSHt68ouif+7ncAGm73fafBugiAvHuta76ZpWvydPbAt0CnAzrzbWdFMZWKY6
UkawDPYqrpChV0bK4JvZ7xpWXgeBpuBICQl/JRWH/V5voH5RdJXsIlKG9HY+nfrc785t3GNdOT/v
m8N/Qz1IT8cvfh4pQxX2MgXKDXL8/EXTw1eJX++zqht9bQSh7p1lLZ8L4aiKF2OH/1T+DySm12tj
A/+XeBHn/5LANxn/Pwj/H/eHlqENdMo2QBSFzB7mmmOjAB4tgeA9xVTOFcBkzG9jFYJOb2u5vBzQ
lWaYOBDMywFBfihHEnCWmfBAvDbKG7NMTSeagXk5oIT14oAoS4aZA+VaJTZIvIAGnOfj1NKwmmFc
kviRTBwIw4uXQHDNvLby47lme7Tc4NGa3oaVwpELT5XHYLpzox62lssN9yOYgQ5lBoYOZNyscXPe
04ZKf4T3J8oNIWnDgY3GuHA0aIMRQpNdRHNTMPKF0VwIBp+V3rA/KoEygy2Hd9DvqiNDzb1NnJeA
4CNjYkNTODImbWhSMlhHHydh1fHNOehKuoJDqSPLwsEyOqIOPm2giCHCRyiVj3rqhXIzMMsJUwnw
OqEKtvTL56F1pSpjWeQb7f1JflvLqrAvsYC8brCZHMjSFvIfIPq3k/8EsUXIf6LE5L/DyX/ZpjGD
ByFLe26tBNF6dJ5/qkLdoAaeqp8q4e/qx1QMxDcSAG+tbN//CcJZvj+HGD7ShBiymanv3yfNwN/V
j4VyTdoMhMs1Q5dm08Ymjhf8VIXnkrWJF8CW4G/khXC5FqsZDkVcExmK9XUS01paMcnI1SbGpR2P
flp91V5bmzIJfm5srkxz3NswB6mLZDITcNP40h/0uorei4WwKoGMbBruddNc6+ZGAggQAghSAjDX
EkCAE8DGVlZIK+GOCGvATRMKBtWPRSJS2iLeIE0DoAysDZQV+9FJWo60F4CLS0oyii/SEjKqj6vk
x3c95QarlP7Ik9JqDkMRJUIUEQ2WwECZqlWeHMdgzC/6X4nmoJ94slDBTy4pqIGK4YoFmdUcBuKV
C1Eki55AMVaH5TCsnEUeQ058taeL2ZIQVj17OXUX0Sh8LFY4Nuob6VBO3MXCXXK/z4IHDgxriBMR
b2UoO54gIqzcmtvPjuc82/MWppCtABvDVLkIGNc3UHk0zrYu+gM17O1fFc+xp9Z8NnGWvgO7wwSr
o5P/0lPPQ8t/fEsQ8PMfXuKZ/HeIdNSmt42GxeT0Bii79AOcLuijZgEudj5Qe3J4mL6/s5gIeU89
v7lMm8BYaQrwVjp7tP4zwe8N9D++weP2/4bEN9j6P0QitIKQkHO5xfI+CZsZVUsbdGnWw1DRwgu2
WSJwaYx17es3+K+pdbWBfAcEbofZu+jrPzxifyP7j8DzEm7/aYhs/z/M/q91r1Xd0tXLvmHq3+Q1
fnUnMWym7mSwP0/spDgVB9pNyWk7U+GWb9tT/kyUpEnTts/u7NtTvtUUxEZbkHipfZfYwNM+RH4f
RPOJz0fS/NTmIkjYeGJHTxoX2tPWaUu4tSfOtNHmhemZ7ZzyjTtnKrbOxFNxap81Bb5xe2Iql1av
b4wVEzADXY48BGFmzFTUkanqY70P1CCkDLAm5LE/utRVwBKznNhkD5gP6BXgSTnM0ECFPGbOJuDN
PtP6AOUatP7QHCOPQ9C0cqla57p2naut3JhXoPv9rmJqeayGCTscZzEl6B/P/xe/vWYbG+W/ZgPj
/2Kzxfz/DiP/QYkrdYgPtbPmaUs86WradV+VBy3DmUBfW8JchSlExOksrgvFPn15FUvVB8ro0sIb
e72TXHYsSl3/yNXMN5D/WqcSof+1Ttn6P0S6VEz1iwLUpOsiZ5oMYrMrTQK70bgd6nY575JI5UM9
Ha7UwdiK7D76AIIQd7VqOZCj9yTbaM6CBncgJgP5rQ8kum8W9UVSfpgMweK3WvLmmdkq7jcoS7pb
wJQjoOjhdb1sCGNd6GkTGusin5uyzLurjS76QC5W+oNQVk5PiOCxTQ09NqJCJ+MWQicjR0AlIxjj
LMCFElMEie6JODRKKCE0OpYEtK7++6YfOR6lFZC8cttYjv9nK+uQ/F8k5b/maYP5fzD+j/J/6FLg
d+owXJ27Sq/6TWzou85Nne/O3F05XkbJD/YSqP6c8wfInTngd73BiYDY68fLIPVzpWuV2uHykOFM
eLf2BMtft3nlIcvsYBjuErtovsa6jc9QFb17Ve7dcVh0b8TL1o0ADltmDAj8JUYBr7PVeRa+RWbW
qnIIafDrBpcGv24QafBlBpLaTonBpNVDCYDpfwX6Xy6O46H1P/L8XxKY/neQFK2L6S28a711+KeI
aNJb9cSdeq6SmJrT1WjEqze21/fO4xX/KdPvoBWillu9cTnpd0YFI9VEcjuMQTdcecE7tVb/gmwD
e2kAOoDWd8BUrKHWU+U0TGohWCgswDgS64BwXy0MNBE4wDDn8gp6ifFVIj+rUhCtJ76Dn8w5HKpb
23cyrhIBdOrfba8+n92mlPPbvB5HA0MjJeBRNIggCdQQCXiAhKSFWjTmuVgJ1EgJ1DgJRJSE4hgJ
RIQEetwDMm4qPehBUUiMfMSJLN7Efvh/GLH3wPY/kW8S9/8Fidn/D8r/o5lnu8AhdoEkLPZxbgJp
0VBJL6EhIvb0tgAOURMy7LGa8LLtJRzPt91kwi6wPYalI9X/fP/+zc7/JYGw/0qCxPS/g6TzG6M/
Uo1wawHM2EgdlSN3yfjQIbyGl95MCg1E2cW0Qs9OauXs5jc7pkmOaeI64Y0fdaRrg0H0ds7Sc+fz
jQOM1iOGN46FoEUYfd8thw7WKMD1bRQ76vrPy0lJbLBOhu7HPqU91qAg7yxyRdnAFbRXiWkvXhMj
zexfJGKzClcm7o1eCIggCy8Ib3RQR4ETsiOAMT4UOW5GuKOwpRtXVVwlW1L4PW5q8A/qpe3i6B+U
sBfMfv5Dyn9wU3oz+U9oEP5fEshj8t8hEpz5Haw+YbXE4pNFVsbEsWI2VmgmCkW+WG7ccHGIWim1
RuCSYR46sY4Q4hsJtl44zMOjzBfJo/QWDZyGi7p50Phueg4S5G00mxQp8a9hByGiER/G+oFHIKaE
p15vIElDU29jH/kB+T9pUz2o/V/C4/+c8iKz/x8kUSM54kEcsdAgOZiYvdFif+BwqWAZyqGJrxjK
sQvF6lyNjXJ1Djqy6Bc5maWCOn5ZNQTFC2CNDRaTHXTbaPVZ6KcvjkLRLfT2I9TFdOY2Kosvj92M
hIaGrWCRzWtZcRIIE4tpuTlY5brv0rCI0Cwd3/4fH7G9jf7HCzwR/++Uxf8/TEIOVwv9dqhluUNX
xieOd/3HX1l4sF/j0+8l1r/YEATi/h/fZPafg6TcB9+Tz7xD3dcOAnvyYN/OnU6m1k8BhOMBbRj8
C9T23Pfgww9wUD57VPYbR3mbQhwDImkA+9RRZrWQdvrCebvNL3b8JNWaLy1RPqlEMXlQPjjW1YAs
CA1Y1p1vTZ07+2keXBidysP0Dl55ebCnrruCFjY4Qp0zsGjiikAkV60LTR8qJgB/BokbDrnptGpW
r646i0XH92uGYfz6F7WIlo3m/eWs3MmDtZjNQf/jFiNlx1K6XagCDbTLTuVfoeLzrwQg/X5Lp5L/
gEtaDiMGQdG3UyE/AJNBmboyMqCYCkENAlZKYa+Vi2slBnq07x5tAQzRmfgp/C0iv6Xwd1JLh45W
sBOPYDZCqTsuAS9lDdTPKijqjy60OJcQj8GLL93krbXRuabovf7oMvHRAvN5MzI7lapQJWGMKxhP
lYAwANqhkgZCid8pVBD+U/9P3Z88OAvbc+5nYPU8wy4nRjRTG0P1V9HNfng3BCBtJEhhh5XPumZF
2EG34UJKOv6rpl2r6hiGdQkb+z/XfXScleMJHVFoC5/SZxF7lsJn9JNs9LAt9VQDi3caCzCKjliT
akKtQf2GWsKGKsunOfSAy088hcM4y+nKBczEir6wNl36nvfyb65R+VGuLwRT2ub7rQ2hsSjiByXW
UBICfqT1VHxxxFBXmmlpugUUzSEgIjcoRchjxbwKLRtgbUcHoZ1K3V0F9Ymd/1xT/RbM89MqISN1
BPTaUX94M0z8/eKeVcXqVkSSa4Rr1k5rza2ohfAXzCOMep06C655s473OxUDFIVzzoYwA/uUVVh1
tpw6fyRfQ333e6IAuO/72hNHxs0Q0FHCJVOGVmJ1vPLescsOQeftxSx9HdvekuEmhLjNMooHY9+0
G6EtpFxhF8o9O+ULOWnsJ9HvodtsNOnQFptMOjKvumrCmFlAODD7QxXyr5TwkkBbQ+Wrdf7NDLmb
JDSaLbHNV0sRQSIbXKhm92otnmxfBgthpHbN3bZmCqLwvbQb0xrCdoUmkCbJRg3wqskY0GF9hOOW
pcdwsDm+JoC/Nf5lbD3ClWPGMTMPS0KuHPHheC2/CimL+yXl9mmjFCmLhaQsMlLekpSPgHil1yFe
6W2IVyokXokR749FvF7y0ew9ku5TMJsDIXSN/LsT9Qpim3+JQlZo1HgLYfMNtPpwrrehq/TAc98E
AhH/2LpR7LQQX6ID/MRU+iNImznTDlDHzb4yCN13jf6vKmxJbCTvMej1jOjeJeAo9NuYVQQ08dLA
gZN8DBzqXiMNB45yMdDkQBsHRg66cfDxlx4NGmQjwJCrI6/eOhMX5Swg68d1y2UBiREsC6HWroml
lgWmER6H8SBVwd7H+tiN0a4niy9K37TO1QtoqjdMaGmFdlwdCib7Fha2JLGIYqyUZLZhwnAz9Y9l
i16n6McHEtfqNzAjyXyc33SvVRPJSKJsZcIlmKy+BrlJo5kBDUBx4mXU1aEJlId/6kLlf8Cf/y0v
FPwyVE29302Q1E/5EAOGpbS1Sv0KGuypVn/U63ehuBpadiywGhLjLiDPLhCMVR2Ix1nPRTHX5JVm
QqOwBe+8aJ8htWaQ/HrIdLhSmgd9Ub9ag/6wjw50lIs3UJfI99//6c0WZutdZKvxDTa4eaqABj5Y
lA4FEikg2uZ0Z+X6swCQ9I6mQUPtAgLGaN0Yga0OmvyRnkm5nkG3vU7lzn87GdHxrYjhbMOivjve
7G7G7OjMjr7TYll3NBqVIUE1DNRM/O4OTtOVsM3yQfq17wWUoT7cPl9W740+pQHmha+Ff5D5QKZi
q1lIq3FSrVFrv8yIkiGjGVLSUsSYghDUq03kAc3ZW09kRm2fiDk9zomUXm8ipeOYSGRRxnN6PBMJ
uLEfbuFVqSZVTxBs6zwOcm50c3cSu6VEORZoLO3w1IHSSafS+RlsxOdK9/pmnPpk/BzDuJ2KPZ16
MgICDTI/f1q6APfjJ9+9Cz7FfgyVSvC8gu8fSoDFPg2VP/9Ozh0o+fRRgmXMB/iY/X9fzfl3o/+v
0JQknvj+W0tg/r8H8f8v5GIkByhc/mv5ySaGWOiBjDsbU72SUQ9kXNTdxzZC2fA4clOT0d1rzZ1s
bNPZdtuhiAvkxl5WgNheqN9FhMe3YfQeOupjtIeDTOpUZWfMcs7VhyONtTKmwhVDIsexcngYS6UM
/OQWAy04g5aTE+gUkDjuJkHIA3NZbKSl6eG7nL2TvwOpljn43Tjpr07ABS5m2xMv7SRmj6Z5KrkW
nDLIIr8D3WZGGRmxyWye+JdN364HR5RpL5z48hY9ivP4vjyRqROYGdVkmk2NozhYyyUM1RzqzS1n
ztxcoec1stYLJzo/lRRf+TWe9Tt6u794eRd74K8nW4Kbbe3VXVCzvEc57hO+Bzfe3WiQsOzKhYbd
jVwEs5LKCNPlMOOznG1JNCuuXGzE5TJTsYxYit8HD0Mt/i8kbgoDyx9/7MNi/PY0k7edF+5fa0kL
t+sjxEWa9RFmeCwkufOR057FKQpJZjc9X3jza2dKTJzt5MILhG9CsPQbfjIVIHdNUC5J9Oh9T/kQ
1z0LlkWJK4kceVU0jpCzYf0kR/syfrK/ds3Tr9DKG2/Qvo8tBL2QvP/1mrnhvtSnc+8Ldv9r8D0L
CuLeZpnmYYX4cu3DL+MQYkLxUt8PMWy9p2POOjLhq8NVtlPbMJctmfDY4gqd0uRGM4XB/bpkilsX
R/O6kqlOVxzixSRTnJi4vDuRTPEm4nD/Npnq3sZR3OlkmjcdR3dLkyleaVyRX5qMbBUwbtldto1l
/oFy9o6pH5WMEAB038qeIxdCGRvi0N1NPgaes97A8lKWk/fhf6lrNJXjoC7icpGDeA4aDShIdVTP
QUc+6TLdT53oxfhLTy7wO8/BRj70BV85yhYh4WqeF/dwD34ZdeDnch7uMurgvob0wrVAvz4gl7Sk
vFflOXfvg53sssQSSyyxxBJLLLHEEkssscQSSyyxxBJLLLHEEkssscQSSyyxxBJLLLHEEkssscQS
Sz9q+n+d8sO5APAAAA==
