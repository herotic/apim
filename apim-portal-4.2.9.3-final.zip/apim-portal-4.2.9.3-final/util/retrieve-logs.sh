#!/bin/bash

#ensure script is running with root permissions
if [[ $EUID != 0 ]]; then
	echo "You need to be root to perform this command."
	exit 1
fi

name=$(date '+%F-%H-%M-%S')
mkdir -p logs/${name}

echo "Gathering logs for Docker Daemon"
#gather logs in json format using grep to filter for only the fields we want and sed to produce valid json from the filtered expression
journalctl -u docker -o json | ./logfilter > logs/${name}/docker.log

echo "Gathering Docker Daemon info"
docker info > logs/${name}/docker-info.log 2>/dev/null

echo "Gathering CA API Developer Portal service history"
docker stack ps portal > logs/${name}/portal-service-history.log

echo "Creating log tarball"
tar -zcf "logs/${name}.tar.gz" logs/${name}
rm -rf logs/${name}
echo "Log archive created in logs/${name}.tar.gz"
