#!/bin/bash

function stop_services {
	services=$(docker service ls --format "{{ .Name }}")
	echo "Stopping services ..."
	for n in $services; do
		if [ ${n} != "portal_portaldb" ] && [ ${n} != "portal_portaldb-slave" ]; then
			docker service rm $n
			sleep 5
		fi
	done
	sleep 20
}

# Ensure all containers except portaldb/slave is removed
function remove_containers {
	var=$(docker ps --format "{{.Names}}" | grep -v portaldb | wc -l)
	if [[ $var -ne 0 ]]; then
		containers=$(docker ps --format "{{.Names}}" | grep -v portaldb)
		for n in $containers; do
			docker stop $n
			docker rm $n
		done
	fi
	echo "Ready to restore"
}

function restore {
	name=${1:-}
	if [ ! -f ${name} ] ; then
		echo "Database restore file $name does not exist"
		exit 1
	fi
	# it's ok to use postgres user and postgres db here
	docker exec -i $(docker ps --format "{{.ID}}" --filter name=portal_portaldb.1) su -c "psql -U postgres -a postgres" postgres < $name
	if [ $? -ne 0 ]; then
		echo "Failed to restore database from backup"
		exit 1
	else
		docker service rm portal_portaldb > /dev/null
		docker service rm portal_portaldb-slave > /dev/null
		echo "Successfully restored database from $name"
		echo "Please re-run portal.sh to restart the services"
	fi
}

if [ "$#" -ne 1 ]; then
	echo "Usage: ./db-restore path_to_file.sql"
	exit 1
fi

stop_services
remove_containers
restore "$@"
