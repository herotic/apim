#!/bin/bash

#ensure script is running with root permissions
if [[ $EUID != 0 ]]; then
	echo "You need to be root to perform this command."
	exit 1
fi


set -e

CHANNEL="stable"
DOWNLOAD_URL="https://download.docker.com"
SUPPORT_MAP="
x86_64-centos-7
x86_64-fedora-24
x86_64-fedora-25
x86_64-fedora-26
x86_64-debian-wheezy
x86_64-debian-jessie
x86_64-debian-stretch
x86_64-ubuntu-trusty
x86_64-ubuntu-xenial
x86_64-ubuntu-zesty
x86_64-ubuntu-artful
s390x-ubuntu-xenial
s390x-ubuntu-zesty
s390x-ubuntu-artful
ppc64le-ubuntu-xenial
ppc64le-ubuntu-zesty
ppc64le-ubuntu-artful
aarch64-ubuntu-xenial
armv6l-raspbian-jessie
armv7l-raspbian-jessie
armv6l-raspbian-stretch
armv7l-raspbian-stretch
armv7l-debian-jessie
armv7l-debian-stretch
armv7l-ubuntu-trusty
armv7l-ubuntu-xenial
armv7l-ubuntu-zesty
armv7l-ubuntu-artful
"

command_exists() {
	command -v "$@" > /dev/null 2>&1
}

get_distribution() {
	lsb_dist=""
	# Every system that we officially support has /etc/os-release
	if [ -r /etc/os-release ]; then
		lsb_dist="$(. /etc/os-release && echo "$ID")"
	fi
	# Returning an empty string here should be alright since the
	# case statements don't act unless you provide an actual value
	echo "$lsb_dist"
}

# Check if this is a forked Linux distro
check_forked() {

	# Check for lsb_release command existence, it usually exists in forked distros
	if command_exists lsb_release; then
		# Check if the `-u` option is supported
		set +e
		lsb_release -a -u > /dev/null 2>&1
		lsb_release_exit_code=$?
		set -e

		# Check if the command has exited successfully, it means we're in a forked distro
		if [ "$lsb_release_exit_code" = "0" ]; then
			# Print info about current distro
			cat <<-EOF
			You're using '$lsb_dist' version '$dist_version'.
			EOF

			# Get the upstream release info
			lsb_dist=$(lsb_release -a -u 2>&1 | tr '[:upper:]' '[:lower:]' | grep -E 'id' | cut -d ':' -f 2 | tr -d '[:space:]')
			dist_version=$(lsb_release -a -u 2>&1 | tr '[:upper:]' '[:lower:]' | grep -E 'codename' | cut -d ':' -f 2 | tr -d '[:space:]')

			# Print info about upstream distro
			cat <<-EOF
			Upstream release is '$lsb_dist' version '$dist_version'.
			EOF
		else
			if [ -r /etc/debian_version ] && [ "$lsb_dist" != "ubuntu" ] && [ "$lsb_dist" != "raspbian" ]; then
				# We're Debian and don't even know it!
				lsb_dist=debian
				dist_version="$(sed 's/\/.*//' /etc/debian_version | sed 's/\..*//')"
				case "$dist_version" in
					9)
						dist_version="stretch"
					;;
					8|'Kali Linux 2')
						dist_version="jessie"
					;;
					7)
						dist_version="wheezy"
					;;
				esac
			fi
		fi
	fi
}

semverParse() {
	major="${1%%.*}"
	minor="${1#$major.}"
	minor="${minor%%.*}"
	patch="${1#$major.$minor.}"
	patch="${patch%%[-.]*}"
}

ee_notice() {
	echo
	echo
	echo "  WARNING: $1 is now only supported by Docker EE"
	echo "           Check https://store.docker.com for information on Docker EE"
	echo
	echo
}

function verlte {
	[ "$1" = $(echo -e "$1\n$2" | sort -V | head -n1) ]
}

function verlt {
	[ "$1" = "$2" ] && return 1 || verlte $1 $2
}

function prompt {
	read -ep "$1: " a
	a=${a:-$2}
	echo "$a"
}

function configureDaemon {
	systemctl enable docker
	systemctl restart docker
}

function check_net {
	if [[ ! $(curl -s ${DOWNLOAD_URL}) ]]; then
		echo "Cannot reach $DOWNLOAD_URL; please install docker version ${VERSION} manually"
		exit 1
	fi
}

do_install() {

	if command_exists docker; then
		UPGRADE=0
		V=$(docker -v | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+')
		echo -e "Found docker version ${V}\n"
		verlt $V $VERSION && UPGRADE=$((UPGRADE | 1 ))
		if [[ $UPGRADE -eq 0 ]]; then
			configureDaemon
			exit 0
		fi
		check_net
		A=$(prompt "Do you want to upgrade docker to version ${VERSION}? [y/N]" "n")
		if [[ ! ${A,,} =~ ^(yes|y)$ ]]; then
			echo -e "\nAPIM portal needs docker version ${VERSION} or newer, exiting."
			exit 1
		fi
	fi

	# perform some very rudimentary platform detection
	lsb_dist=$( get_distribution )
	lsb_dist="$(echo "$lsb_dist" | tr '[:upper:]' '[:lower:]')"

	case "$lsb_dist" in

		ubuntu)
			if command_exists lsb_release; then
				dist_version="$(lsb_release --codename | cut -f2)"
			fi
			if [ -z "$dist_version" ] && [ -r /etc/lsb-release ]; then
				dist_version="$(. /etc/lsb-release && echo "$DISTRIB_CODENAME")"
			fi
		;;

		debian|raspbian)
			dist_version="$(sed 's/\/.*//' /etc/debian_version | sed 's/\..*//')"
			case "$dist_version" in
				9)
					dist_version="stretch"
				;;
				8)
					dist_version="jessie"
				;;
				7)
					dist_version="wheezy"
				;;
			esac
		;;

		centos)
			if [ -z "$dist_version" ] && [ -r /etc/os-release ]; then
				dist_version="$(. /etc/os-release && echo "$VERSION_ID")"
			fi
		;;

		rhel|ol|sles)
			ee_notice "$lsb_dist"
			exit 1
			;;

		*)
			if command_exists lsb_release; then
				dist_version="$(lsb_release --release | cut -f2)"
			fi
			if [ -z "$dist_version" ] && [ -r /etc/os-release ]; then
				dist_version="$(. /etc/os-release && echo "$VERSION_ID")"
			fi
		;;

	esac

	# Check if this is a forked Linux distro
	check_forked

	# Check if we actually support this configuration
	if ! echo "$SUPPORT_MAP" | grep "$(uname -m)-$lsb_dist-$dist_version" >/dev/null; then
		cat >&2 <<-'EOF'

		Cannot install docker; please visit the following URL for more detailed installation instructions:

		https://docs.docker.com/engine/installation/

		EOF
		exit 1
	fi

	# Run setup for each distro accordingly
	case "$lsb_dist" in
		ubuntu|debian|raspbian)
			pre_reqs="apt-transport-https ca-certificates curl"
			if [ "$lsb_dist" = "debian" ] && [ "$dist_version" = "wheezy" ]; then
				pre_reqs="$pre_reqs python-software-properties"
				backports="deb http://ftp.debian.org/debian wheezy-backports main"
				if ! grep -Fxq "$backports" /etc/apt/sources.list; then
					echo "$backports" >> /etc/apt/sources.list
				fi
			else
				pre_reqs="$pre_reqs software-properties-common"
			fi

			if [ "$lsb_dist" = "ubuntu" ] && [ "$dist_version" = "artful" ]; then
				dist_version="zesty"
			fi

			if ! command -v gpg > /dev/null; then
				pre_reqs="$pre_reqs gnupg"
			fi
			apt_repo="deb [arch=$(dpkg --print-architecture)] $DOWNLOAD_URL/linux/$lsb_dist $dist_version $CHANNEL"
			(
				apt-get update -qq >/dev/null
				apt-get install -y -qq ${pre_reqs} >/dev/null
				curl -fsSL "$DOWNLOAD_URL/linux/$lsb_dist/gpg" | apt-key add -qq - >/dev/null
				echo "$apt_repo" > /etc/apt/sources.list.d/docker.list
				if [ "$lsb_dist" = "debian" ] && [ "$dist_version" = "wheezy" ]; then
					sed -i "/deb-src.*download\.docker/d" /etc/apt/sources.list.d/docker.list
				fi
				apt-get update -qq >/dev/null
				apt-get install -y -qq --no-install-recommends docker-ce=${VERSION} >/dev/null
				configureDaemon
			)
			exit 0
			;;
		centos|fedora)
			yum_repo="$DOWNLOAD_URL/linux/$lsb_dist/docker-ce.repo"
			if [ "$lsb_dist" = "fedora" ]; then
				if [ "$dist_version" -le "24" ]; then
					echo "Error: Only Fedora >24 are supported"
					exit 1
				fi
				pkg_manager="dnf"
				config_manager="dnf config-manager"
				enable_channel_flag="--set-enabled"
				pre_reqs="dnf-plugins-core"
			else
				pkg_manager="yum"
				config_manager="yum-config-manager"
				enable_channel_flag="--enable"
				pre_reqs="yum-utils"
			fi
			(
				$pkg_manager install -y -q $pre_reqs
				$config_manager --add-repo $yum_repo
				$pkg_manager makecache
				$pkg_manager install -y -q docker-ce-${VERSION}*
				configureDaemon
			)
			exit 0
			;;
	esac
	exit 1
}

VERSION=${1:-17.09.0}
do_install
