#!/bin/bash

set -e

#ensure the bash version in the customer's machine is compatible version
if (( ${BASH_VERSION%%.*} < 4 )); then
	echo "Your version of bash (${BASH_VERSION}) is too old; please upgrade"
	exit 1
fi

#ensure script is running with root permissions
if [[ $EUID != 0 ]]; then
	echo "You need to be root to perform this command."
	exit 1
fi

#ensure the input "SERVER_HOSTNAME" is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <server_name>"
    echo "       server_name  The FQDN domain name of the tenant, for example, tenant1.mycompany.com"
    exit 1
fi

function ask_for_input {
	read -p "Organization Name: " -e organization
	read -p "Organizational Unit Name: " -e organizational_unit
	read -p "City or Locality Name: " -e city
	read -p "State or Province Name: " -e state
	read -p "Country Name (2 letter code): " -e country
	read -p "Email Address: " -e email
}

function generate_ssl_cert {
	name=${1:-}
	cert_name="../certs/${name}"
	PASS="$(/usr/bin/hexdump -e '"%4x"' -n 48  /dev/urandom)"
	openssl genrsa -des3 -out ${cert_name}.key -passout pass:"${PASS}" 2048
	openssl rsa -in ${cert_name}.key -passin pass:"${PASS}" -out ${cert_name}.pem
	openssl req -new -key ${cert_name}.pem -out ${cert_name}.csr -days 365 -subj "/emailAddress=$email/CN=$SERVER_HOSTNAME/O=$organization/OU=$organizational_unit/C=$country/ST=$state/L=$city"
	openssl x509 -req -signkey ${cert_name}.pem -in ${cert_name}.csr -out ${cert_name}.crt

	rm -rf ${cert_name}.key
}

function update_dispatcher {
	SERVER_HOSTNAME=${1:-}

	# generate certs if it doesn't exist
	if [ ! -f "../certs/${SERVER_HOSTNAME}.crt" ] || [ ! -f "../certs/${SERVER_HOSTNAME}.pem" ] ; then
		echo "No valid certficates found at ../certs/${SERVER_HOSTNAME}.crt or ../certs/${SERVER_HOSTNAME}.pem, this will be generated."
		ask_for_input
		generate_ssl_cert ${SERVER_HOSTNAME}
	fi

	# secrets & config --- there's no update command so we'll have to create a new one, remove the old one and update the service accordingly
	docker service update --detach=false --config-rm ${SERVER_HOSTNAME}.conf --secret-rm ${SERVER_HOSTNAME}.crt --secret-rm ${SERVER_HOSTNAME}.pem portal_dispatcher

	conf="$(docker config ls --filter "Name=${SERVER_HOSTNAME}.conf" --format '{{ .ID }}')"
	if [ ! -z "$conf" ] ; then
		docker config rm $conf
	fi
	cat <<EOF | docker config create ${SERVER_HOSTNAME}.conf -
	server {
		listen              8443 ssl;
		server_tokens       off;
		server_name         ${SERVER_HOSTNAME};
		ssl_protocols       TLSv1.2;
		ssl_ciphers         ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA256:AES256-SHA256:AES:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!aECDH:!EDH-DSS-DES-CBC3-SHA:!EDH-RSA-DES-CBC3-SHA:!KRB5-DES-CBC3-SHA;
		ssl_session_cache   shared:SSL:512000;
		ssl_session_timeout 300;

		ssl_certificate     /run/secrets/${SERVER_HOSTNAME}.crt;
		ssl_certificate_key /run/secrets/${SERVER_HOSTNAME}.pem;

		include /etc/nginx/server_base.conf;
		include /etc/nginx/*.nginx;
	}
EOF

	# create or update the cert
	crt="$(docker secret ls --filter "Name=${SERVER_HOSTNAME}.crt" --format '{{ .ID }}')"
	if [ ! -z "$crt" ] ; then
		docker secret rm $crt
	fi
	docker secret create ${SERVER_HOSTNAME}.crt ../certs/${SERVER_HOSTNAME}.crt
	# create or update the pem
	pem="$(docker secret ls --filter "Name=${SERVER_HOSTNAME}.pem" --format '{{ .ID }}')"
	if [ ! -z "$pem" ] ; then
		docker secret rm $pem
	fi
	docker secret create ${SERVER_HOSTNAME}.pem ../certs/${SERVER_HOSTNAME}.pem
	docker service update --detach=false --config-add src=${SERVER_HOSTNAME}.conf,target="/etc/nginx/sites-enabled/${SERVER_HOSTNAME}.conf" --secret-add ${SERVER_HOSTNAME}.crt --secret-add ${SERVER_HOSTNAME}.pem portal_dispatcher
}

update_dispatcher "$@"
