#!/bin/bash

set -e

#ensure script is running with root permissions
if [[ $EUID != 0 ]]; then
	echo "You need to be root to perform this command."
	exit 1
fi

function command_exists {
	command -v "$@" > /dev/null 2>&1
}

function usage {
	>&2 echo "
	usage: $0 [OPTIONS] [-n | --node nodetype]

	Configure your current swarm node to be compatible with on-prem portal deployment

	OPTIONS:
		-h | --help: Show help message
		-n | --node: The node type you are configuring (manager | worker)
	"
	exit 1
}

function tmpfile {
	f="$(mktemp)"
	echo "$1" | tr ' ' '\n' | sort -u > "$f"
	echo "$f"
}

function ports_open {
	a=$(tmpfile "$1")
	b=$(tmpfile "$2")
	r=$(comm -23 "$a" "$b" | wc -l)
	rm "$a" "$b"
	echo "$r"
}

function openPorts {
	local nodetype="$1"
	local ports=""
	case ${nodetype} in
	manager)
		ports="2376/tcp 2377/tcp 7946/tcp 9443/tcp 4789/udp 7946/udp"
		;;
	worker)
		ports="2377/tcp 2376/tcp 7946/tcp 4789/udp 7946/udp"
		;;
	'')
		echo "Node type not specified"
		usage
		;;
	*)
		echo "Unsupported node type '${nodetype}'"
		usage
		;;
	esac
	if command_exists firewall-cmd; then
		systemctl start firewalld
		fw="$(firewall-cmd --list-ports)"
		if [ "$(ports_open "$ports" "$fw")" -eq 0 ]; then
			return
		fi
		for port in ${ports}; do
			firewall-cmd --add-port=${port} --permanent &> /dev/null
		done
		firewall-cmd --reload > /dev/null
		sleep 5
	elif command_exists ufw; then
		ufw enable >/dev/null 2>&1
		fw="$(ufw show added | grep -oE "[0-9].*$")"
		if [ "$(ports_open "$ports" "$fw")" -eq 0 ]; then
			return
		fi
		for port in ${ports}; do
			sleep 1
			ufw allow ${port} >/dev/null 2>&1
		done
	else
		echo "Unknown firewall or firewall absent, skipping opening ports"
		return
	fi
}

function main {
	local nodetype=""

	while true; do
	case "${1:-}" in
		-h | --help	) usage ;;
		-n | --node	) shift; nodetype="$1"; shift ;;
		-- ) shift; break ;;
		"" ) break ;;
		* ) echo "Invalid parameter '$1'"; usage ;;
	esac
	done
	if [[ -z $nodetype ]]; then
		usage
	fi

	echo 'vm.max_map_count=262144' > /etc/sysctl.d/vm.conf
	echo '*               soft     nofile          65536' > /etc/security/limits.d/99limit.conf
	echo '*               hard     nofile          65536' >> /etc/security/limits.d/99limit.conf
	sysctl -p /etc/sysctl.d/vm.conf > /dev/null

	openPorts ${nodetype}
	# restart docker even if ports are open
	systemctl restart docker
}

main "$@"
