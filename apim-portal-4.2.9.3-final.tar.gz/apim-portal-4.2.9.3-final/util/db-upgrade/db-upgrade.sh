#!/bin/bash
set -o errexit
set -o pipefail

USER_CONFIG=${PORTAL_USER_CONFIG:-/etc/ca/apim-portal/portal-local.inc}
source $USER_CONFIG

function upgrade_database {
	java -jar -Dapim_tenant_id=${PORTAL_HOSTNAME} liquibase-3.2.2.jar \
		--driver=org.mariadb.jdbc.Driver \
		--classpath=mariadb-java-client-2.2.0.jar \
		--changeLogFile=portaldb-changelogs/upgrade-changelog.xml \
		--url="jdbc:mysql://${PORTAL_DATABASE_HOST}:${PORTAL_DATABASE_PORT}/portal" \
		--username=${PORTAL_DATABASE_USERNAME} \
		--password=${PORTAL_DATABASE_PASSWORD} \
		--logLevel=debug update

	java -jar liquibase-3.2.2.jar \
		--driver=org.mariadb.jdbc.Driver \
		--classpath=mariadb-java-client-2.2.0.jar \
		--changeLogFile=otk-changelogs/otkdb-upgrade-changelog.xml \
		--url="jdbc:mysql://${PORTAL_DATABASE_HOST}:${PORTAL_DATABASE_PORT}/${PORTAL_HOSTNAME}_otk_db" \
		--username=${PORTAL_DATABASE_USERNAME} \
		--password=${PORTAL_DATABASE_PASSWORD} \
		--logLevel=debug update
}

function ensure_java {
	if [[ -n 'which java' ]]; then
		sudo yum install java -y
	fi
}

function main {
	ensure_java
	upgrade_database
}

main "$@"
