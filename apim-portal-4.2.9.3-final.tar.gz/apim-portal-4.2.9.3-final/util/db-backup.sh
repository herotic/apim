#!/bin/bash

function backup {
	if [ ! -d "../backup" ]; then
		mkdir -p ../backup
	fi

	name=postgres_backup-$(date '+%Y-%m-%d-%H-%M-%S').sql
	docker exec -it $(docker ps --format "{{.ID}}" --filter name=portal_portaldb.1) su -c "pg_dumpall -U postgres -c" postgres > ../backup/$name
}

backup "$@"
