#!/bin/bash

function spinner {
	local delay=1
	local spinstr='|/-\'
	local pad=$(printf '%0.1s' "-"{1..60})

	local r=0

	printf '%s ' "$1"
	printf '%*.*s ' 0 $((40 - ${#1} )) "$pad"

	local c=0
	while [ $r -lt 1 ]; do
		if [ $c -gt 1200 ]; then
			printf "\b\b\b FAILED - has not come up within 20 minutes.\n"
			return 1
		fi
		local temp="${spinstr#?}"
		printf "[%c]" "$spinstr"
		local spinstr=$temp${spinstr%"$temp"}
		sleep $delay
		printf "\b\b\b"
		c=$(( c + 1 ))
		rep="$(docker service ls -f "name=$1" --format "{{.Replicas}}")"
		r=$(echo $rep | cut -d'/' -f 1)
	done
	printf "  \b\b\b RUNNING\n"
}

echo 'Checking for CA API Developer services'
for i in $(docker stack services portal --format "{{.Name}}")
do
	spinner $i
	if [ $? -ne 0 ]; then
		echo 'CA API Developer failed to start, please run util/retrieve-logs.sh to gather log files.'
		exit 1
	fi
done
