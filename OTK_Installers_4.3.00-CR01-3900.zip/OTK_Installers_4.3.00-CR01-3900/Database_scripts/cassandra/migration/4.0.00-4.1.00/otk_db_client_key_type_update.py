import argparse
import logging

from cassandra import auth
from cassandra import cluster

LOG = logging.getLogger(__name__)


def update_master_client_keys(session, keyspace):
    """Identify existing Client Keys as Master Keys (key=secret)
    :param session: Cassandra session object
    :param keyspace: name of the Keyspace to connect to
    """
    LOG.debug('Preparing Client table...')
    session.set_keyspace(keyspace)
    client_key_stmt = cluster.SimpleStatement(
        'SELECT client_ident, client_key, secret '
        'FROM oauth_client_key',
    )
    client_key_update_stmt = cluster.SimpleStatement(
        'UPDATE oauth_client_key SET master=%s WHERE client_key=%s '
        'AND client_ident=%s',
    )
    try:
        client_keys = session.execute(client_key_stmt)
        count = 0
        master = 0
        for client_key in client_keys:
            if client_key.client_key == client_key.secret:
                master = 1
            session.execute(
                client_key_update_stmt,
                (
                    master,
                    client_key.client_key,
                    client_key.client_ident,
                )
            )
            master = 0
            count += 1
        LOG.info('Done!')
        LOG.info('Updated {} rows'.format(count))
    except Exception as e:
        LOG.exception(e)


def connect(host=None, username=None, password=None, port=None):
    """
    Create a session object
    :param host: the hostname/IP of the cluster
    :param username: admin username for the cluster
    :param password:  admin password for the cluster
    :param port: port for the cluster
    :return: a session object
    """

    attrs = {}
    if host:
        attrs['contact_points'] = [host]
    if username:
        auth_provider = auth.PlainTextAuthProvider(
            username=username,
            password=password,
        )
        attrs['auth_provider'] = auth_provider
    if port:
        attrs['port'] = port

    conn = cluster.Cluster(**attrs)
    return conn.connect()


def parse_args(args=None):
    """
    Build cli arguments using an argsparse parser
    :param args:
    :return: parsed cli arguments
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-d',
        '--debug',
        action='store_true',
        help="enable debug messages"
    )
    parser.add_argument(
        '--host',
        help='Cassandra Cluster host',
    )
    parser.add_argument(
        '-p',
        '--port',
        help='Cassandra listen port',
    )
    parser.add_argument(
        '--username',
        help='admin username for Cassandra host',
    )
    parser.add_argument(
        '--password',
        help='admin password for Cassandra host',
    )
    parser.add_argument(
        '-k',
        '--keyspace',
        help='Cassandra Keyspace name',
    )
    return parser.parse_args(args=args)


def run(args=None):
    args = parse_args(args=args)

    level = logging.INFO
    if args.debug:
        level = logging.DEBUG
    logging.basicConfig(level=level)

    session = connect(
        host=args.host,
        username=args.username,
        password=args.password,
        port=args.port,
    )

    keyspace = args.keyspace if args.keyspace else 'otk_db'
    update_master_client_keys(session, keyspace)


if __name__ == '__main__':
    run()
