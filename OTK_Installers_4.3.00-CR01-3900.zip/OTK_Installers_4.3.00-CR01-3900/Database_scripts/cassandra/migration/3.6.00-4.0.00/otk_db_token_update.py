import argparse
import logging

from cassandra import auth
from cassandra import cluster

LOG = logging.getLogger(__name__)


def update_token_with_client_ident(session, keyspace):
    """
    Perform required updates for OTK 4.0.00 upgrade
    :param session: Cassandra session object
    :param keyspace: name of the Keyspace to connect to
    """
    LOG.info('Updating Token tables...')
    session.set_keyspace(keyspace)
    token_client_key_stmt = cluster.SimpleStatement(
        'SELECT otk_token, client_ident, resource_owner, created, '
        'client_key FROM oauth_access_token',
    )
    client_ident_client_key_stmt = cluster.SimpleStatement(
        'SELECT client_ident FROM oauth_client_key WHERE client_key=%s',
    )
    token_update_client_ident_stmt = cluster.SimpleStatement(
        'UPDATE oauth_access_token SET client_ident=%s WHERE otk_token=%s',
    )
    token_client_ident_view_update_stmt = cluster.SimpleStatement(
        'INSERT INTO oauth_access_token_view_client_ident (otk_token, '
        'client_ident, resource_owner, created) VALUES (%s, %s, %s, %s)',
    )
    tokens = session.execute(token_client_key_stmt)
    count = 0
    for token in tokens:
        client_key = session.execute(
            client_ident_client_key_stmt,
            (token.client_key,),
        )
        client_ident = client_key[0].client_ident
        session.execute(
            token_update_client_ident_stmt,
            (client_ident, token.otk_token,),
        )
        session.execute(
            token_client_ident_view_update_stmt,
            (
                token.otk_token,
                client_ident,
                token.resource_owner,
                token.created,
            )
        )
        count += 1
    LOG.info('Done!')
    LOG.info('Updated {} rows'.format(count))


def connect(host=None, username=None, password=None, port=None):
    """
    Create a session object
    :param host: the hostname/IP of the cluster
    :param username: admin username for the cluster
    :param password:  admin password for the cluster
    :param port: port for the cluster
    :return: a session object
    """

    attrs = {}
    if host:
        attrs['contact_points'] = [host]
    if username:
        auth_provider = auth.PlainTextAuthProvider(
            username=username,
            password=password,
        )
        attrs['auth_provider'] = auth_provider
    if port:
        attrs['port'] = port

    conn = cluster.Cluster(**attrs)
    return conn.connect()


def parse_args(args=None):
    """
    Build cli arguments using an argsparse parser
    :param args:
    :return: parsed cli arguments
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-d',
        '--debug',
        action='store_true',
        help="enable debug messages"
    )
    parser.add_argument(
        '--host',
        help='Cassandra Cluster host',
    )
    parser.add_argument(
        '-p',
        '--port',
        help='Cassandra listen port',
    )
    parser.add_argument(
        '--username',
        help='admin username for Cassandra host',
    )
    parser.add_argument(
        '--password',
        help='admin password for Cassandra host',
    )
    parser.add_argument(
        '-k',
        '--keyspace',
        help='Cassandra Keyspace name',
    )
    return parser.parse_args(args=args)


def run(args=None):
    args = parse_args(args=args)

    level = logging.INFO
    if args.debug:
        level = logging.DEBUG
    logging.basicConfig(level=level)

    session = connect(
        host=args.host,
        username=args.username,
        password=args.password,
        port=args.port,
    )

    keyspace = args.keyspace if args.keyspace else 'otk_db'
    update_token_with_client_ident(session, keyspace)


if __name__ == '__main__':
    run()
