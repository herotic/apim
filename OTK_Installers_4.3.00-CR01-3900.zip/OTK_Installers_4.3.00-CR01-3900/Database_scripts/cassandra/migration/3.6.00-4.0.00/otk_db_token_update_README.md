# Cassandra Token Update Script (3.6.00-4.0.00)

## Installation
* Install the latest [Python 2.7] (https://www.python.org/downloads/release/python-2713/)

    **Note:** The version that ships with OSX will most likely be out of date. Please download the latest stable version from the link above.
    
* Upgrade pip:
    * Linux/OSX:
    
        ```
        pip install -U pip
        ```
        If pip is not installed, use easy_install to install it:
    
        ```
        python easy_install pip
        ```
    * Windows:
        ```
        python -m pip install -U pip
        ```
* Install the Cassandra Python driver
    ```
    pip install cassandra-driver
    ```
    
    **Note:** At the time of this writing `3.8.0` is the latest version of cassandra-driver

## Usage
Execute the python script with `-h` to see usage information:
```
python otk_db_client_key_type_update.py -h
```
Output:
```
usage: otk_db_token_update.py [-h] [-d] [--host HOST] [-p PORT]
                              [--username USERNAME] [--password PASSWORD]
                              [-k KEYSPACE]

optional arguments:
  -h, --help            show this help message and exit
  -d, --debug           enable debug messages
  --host HOST           Cassandra Cluster host
  -p PORT, --port PORT  Cassandra listen port
  --username USERNAME   admin username for Cassandra host
  --password PASSWORD   admin password for Cassandra host
  -k KEYSPACE, --keyspace KEYSPACE
                        Cassandra Keyspace name
```

With no parameters specified, the script will attempt to connect to a Cassandra Cluster listening on `127.0.0.1` without any credentials. The keyspace will also default to `otk_db`. To change this behaviour, add command line arguments as specified above.
```
python otk_db_token_update.py
```

Sample successful output:

```
INFO:cassandra.policies:Using datacenter 'datacenter1' for DCAwareRoundRobinPolicy (via host '127.0.0.1');
if incorrect, please specify a local_dc to the constructor, or limit contact points to local cluster nodes
INFO:__main__:Updating Token tables...
INFO:__main__:Done!
INFO:__main__:Updated 10000 rows
```

## Troubleshooting

### Problem:
* When running the script, if you get the following error:
    ```
    Traceback (most recent call last):
      File "cassandra_token_update.py", line 4, in <module>
        from cassandra import auth
    ImportError: No module named cassandra
    ```

### Solution:
* `cassandra-driver` is not installed. Use `pip` to install `cassandra-driver` and try again

### Problem:
* When running the script, you get the following error:
    ```
    Traceback (most recent call last):                                                                         
      File "cassandra_token_update.py", line 142, in <module> 
        run()
      File "cassandra_token_update.py", line 138, in run 
        update_token_with_client_ident(session, keyspace)
      File "cassandra_token_update.py", line 50, in update_token_with_client_ident
        (client_ident, token.otk_token,),
      File "cassandra/cluster.py", line 2012, in cassandra.cluster.Session.execute (cassandra/cluster.c:35058)
      File "cassandra/cluster.py", line 3801, in cassandra.cluster.ResponseFuture.result (cassandra/cluster.c:7
    3464)
    cassandra.WriteTimeout: Error from server: code=1100 [Coordinator node timed out waiting for replica nodes'responses] message="Operation timed out - received only 0 responses." info={'received_responses': 0, 'required_responses': 1, 'consistency': 'LOCAL_ONE'}
    ```

### Solution:
* The script can be run multiple times without conflict, so if you receive a timeout, try running the script again. If it fails again, add the debug flag (-d) to the command to see if there is any further information on what is causing the timeout.

