-- CA Technologies Inc.
-- Upgrade database schema from 3.6.00 to 4.0.00
-- 2017-02-07

UPDATE otk_version SET current_version = 'otk4.0.00';

ALTER TABLE oauth_id_token MODIFY COLUMN jwt_id varchar(512);

ALTER TABLE oauth_token ADD client_ident varchar(128) not null COMMENT 'Client';

CREATE INDEX oat_idx_rowner_client_ident ON oauth_token(resource_owner, client_ident);

-- Populate the new client_ident column of oauth_token with existing data
UPDATE oauth_token token JOIN oauth_client_key client_key ON token.client_key = client_key.client_key SET token.client_ident = client_key.client_ident;
