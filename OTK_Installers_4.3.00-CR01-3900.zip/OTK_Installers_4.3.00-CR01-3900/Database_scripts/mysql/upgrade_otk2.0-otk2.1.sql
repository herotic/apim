-- CA Technologies Inc.
-- Database schema for OTK 2.1
-- 2014/06/11
--
-- Use this database upgrade schema if you are using OTK and not MAG (Mobile Access Gateway). Refer to MAG if that is
-- used and ignore this file unless OTK is used in its own database schema with no connection between this database and
-- the one used with MAG.
--
-- Upgrade OTK database schema from otk2.0 to otk2.1
-- - adding mag_id_token
-- - update version to otk2.1
--
-- This table will contain all id_token
--
CREATE TABLE mag_id_token (
  resource_owner varchar(128) not null,
  azp varchar(128) not null,
  sub varchar(128) null,
  jwt_id varchar(128) null,
  jwt mediumtext not null,
  salt varchar(128) null,
  shared_secret varchar(128) null,
  shared_secret_type varchar(128) null,
  iss varchar(128) not null,
  expiration bigint not null COMMENT 'expiration date in seconds',
  constraint pk_mag_id_token primary key (resource_owner, azp)
) ENGINE=InnoDB DEFAULT CHARACTER SET utf8;
--
-- Updating the version to otk2.1
--
UPDATE otk_version SET current_version='otk2.1';