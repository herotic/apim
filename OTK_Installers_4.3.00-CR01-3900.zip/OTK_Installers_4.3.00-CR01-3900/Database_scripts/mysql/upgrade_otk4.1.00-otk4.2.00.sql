-- CA Technologies Inc.
-- Upgrade database schema from 4.1.00 to 4.2.00
-- 2017-07-25

UPDATE otk_version SET current_version = 'otk4.2.00';
