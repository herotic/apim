-- CA Technologies
-- Database upgrade schema for OTK 3.1.0
-- 2015/06/15
--

-- Updating the version to otk3.0.0
--
UPDATE otk_version SET current_version='otk3.1.0';