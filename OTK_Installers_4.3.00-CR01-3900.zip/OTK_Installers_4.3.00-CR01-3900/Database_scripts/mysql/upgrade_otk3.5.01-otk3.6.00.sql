-- CA Technologies
-- Database upgrade schema for OTK 3.6.00
-- 2016-08-15
--

-- Updating the version to otk3.6.00
--
UPDATE otk_version SET current_version='otk3.6.00';
