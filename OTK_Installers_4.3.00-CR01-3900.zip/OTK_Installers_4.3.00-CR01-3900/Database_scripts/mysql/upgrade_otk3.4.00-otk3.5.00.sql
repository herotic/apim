-- CA Technologies
-- Database upgrade schema for OTK 3.5.00
-- 2016/07
--

-- Updating the version to otk3.5.00
--
UPDATE otk_version SET current_version='otk3.5.00';
