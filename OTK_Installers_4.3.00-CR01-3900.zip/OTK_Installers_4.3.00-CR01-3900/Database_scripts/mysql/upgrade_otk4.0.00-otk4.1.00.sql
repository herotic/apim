-- CA Technologies Inc.
-- Upgrade database schema from 4.0.00 to 4.1.00

UPDATE otk_version SET current_version = 'otk4.1.00';
