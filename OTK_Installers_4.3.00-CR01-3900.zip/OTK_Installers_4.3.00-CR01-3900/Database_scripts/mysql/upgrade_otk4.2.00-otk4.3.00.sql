-- CA Technologies Inc.
-- Upgrade database schema from 4.2.00 to 4.3.00
-- 2017-12-14

UPDATE otk_version SET current_version = 'otk4.3.00';

ALTER TABLE oauth_client
    MODIFY client_ident varchar(255),
    MODIFY name varchar(255) NOT NULL;

ALTER TABLE oauth_client_key 
    MODIFY secret MEDIUMTEXT NOT NULL,
    MODIFY client_key varchar(255),
    MODIFY client_ident varchar(255) NOT NULL,
    MODIFY client_name varchar(255) NOT NULL,
    MODIFY scope varchar(4000) NOT NULL DEFAULT 'oob';

ALTER TABLE oauth_token
    MODIFY client_key varchar(255) NOT NULL,
    MODIFY client_ident varchar(255) NOT NULL,
    MODIFY scope varchar(4000),
    MODIFY client_name varchar(255) NOT NULL;

ALTER TABLE oauth_initiate
    MODIFY client_key varchar(255) NOT NULL,
    MODIFY client_name varchar(255) NOT NULL,
    MODIFY scope varchar(4000);

ALTER TABLE oauth_id_token
    MODIFY azp varchar(255) NOT NULL,
    MODIFY salt varchar(384),
    MODIFY sub varchar(255),
    MODIFY iss varchar(255) NOT NULL,
    MODIFY shared_secret MEDIUMTEXT;

ALTER TABLE portal_apikey
    MODIFY apikey_pk varchar(255);
