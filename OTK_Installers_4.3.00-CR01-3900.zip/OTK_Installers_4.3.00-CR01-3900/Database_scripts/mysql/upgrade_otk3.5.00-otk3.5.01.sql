-- CA Technologies
-- Database upgrade schema for OTK 3.5.01
-- 2016/07
--

-- Updating the version to otk3.5.01
--
UPDATE otk_version SET current_version='otk3.5.01';

ALTER TABLE oauth_client DROP index uk_oc_name;

-- add IDX to oauth_client
CREATE INDEX oc_idx_clientname ON oauth_client(name);

