-- CA Technologies
-- Database upgrade schema for OTK 3.0.0
-- Upgrades otk database schema otk2.1 to otk3.0.0 for Oracle
-- 2015/01/30
--
-- Rename 'mag_id_token' to 'oauth_id_token'
RENAME TABLE mag_id_token TO oauth_id_token
/
--
-- Updating the version to otk3.0.0
--
UPDATE otk_version SET current_version='otk3.0.0'
/
COMMIT
/