-- CA Technologies Inc.
-- Upgrade database schema from 4.2.00 to 4.3.00
-- 2017-12-14

UPDATE otk_version SET current_version = 'otk4.3.00'
/

ALTER TABLE oauth_client MODIFY (
    client_ident varchar(255),
    name varchar(255)
)
/

ALTER TABLE oauth_client_key MODIFY (
    client_key varchar(255),
    client_ident varchar(255),
    client_name varchar(255),
    "SCOPE" varchar(4000)
)
/
ALTER TABLE oauth_client_key add secret_copy varchar2(4000)
/
ALTER TABLE oauth_client_key MODIFY secret NULL
/
UPDATE oauth_client_key SET secret_copy = secret, secret=null
/
ALTER TABLE oauth_client_key MODIFY secret long
/
ALTER TABLE oauth_client_key MODIFY secret clob
/
UPDATE oauth_client_key SET secret = secret_copy
/
ALTER TABLE oauth_client_key MODIFY secret not null
/
ALTER TABLE oauth_client_key DROP COLUMN secret_copy
/

ALTER TABLE oauth_token MODIFY (
    client_key varchar(255),
    client_name varchar(255),
    client_ident varchar(255),
    "SCOPE" varchar(4000)
)
/

ALTER TABLE oauth_initiate MODIFY (
    client_key varchar(255),
    client_name varchar(255),
    "SCOPE" varchar(4000)
)
/

ALTER TABLE oauth_id_token MODIFY (
    azp varchar(255),
    sub varchar(255),
    salt varchar(384),
    iss varchar(255)
)
/

ALTER TABLE portal_apikey MODIFY (
    apikey_pk varchar(255)
)
/
ALTER TABLE oauth_id_token add shared_secret_copy varchar2(4000)
/
UPDATE oauth_id_token SET shared_secret_copy = shared_secret, shared_secret=null
/
ALTER TABLE oauth_id_token MODIFY shared_secret long
/
ALTER TABLE oauth_id_token MODIFY shared_secret clob
/
UPDATE oauth_id_token SET shared_secret = shared_secret_copy
/
ALTER TABLE oauth_id_token DROP COLUMN shared_secret_copy
/
COMMIT
/
