-- CA Technologies
-- Database upgrade schema for OTK 3.4.00
-- 2016/03
--

-- Updating the version to otk3.4.00
--
UPDATE otk_version SET current_version='otk3.4.00'
/
--
-- Adding a new table to have CA API Portal API Keys in their own table
--
-- CA API Portal API Keys
--
CREATE TABLE portal_apikey (
  apikey_pk varchar(128) primary key,
  apikey varchar(255) unique not null,
  apikey_secret varchar(255) unique not null,
  status varchar(100) not null,
  organization_id varchar(128) not null,
  organization varchar(255) not null,
  label varchar(255) not null,
  created_by varchar(128) not null,
  modified_by varchar(128) not null,
  created number DEFAULT 0 not null,
  updated number DEFAULT 0 not null,
  apis CLOB null,
  value_xml CLOB not null
)
/
CREATE INDEX papikey_updated ON portal_apikey (updated)
/
COMMIT
/