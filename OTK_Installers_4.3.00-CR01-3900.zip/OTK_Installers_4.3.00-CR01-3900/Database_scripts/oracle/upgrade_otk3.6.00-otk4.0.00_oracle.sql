-- CA Technologies Inc.
-- Upgrade database schema from 3.6.00 to 4.0.00
-- 2017-02-07

UPDATE otk_version SET current_version = 'otk4.0.00'
/
ALTER TABLE oauth_token ADD client_ident varchar(128)
/
CREATE INDEX oat_idx_rowner_client_ident ON oauth_token(resource_owner, client_ident)
/
ALTER TABLE oauth_id_token MODIFY jwt_id varchar(512)
/
-- Populate the new client_ident column of oauth_token with existing data
UPDATE oauth_token token SET token.client_ident = (SELECT client_key.client_ident FROM oauth_client_key client_key WHERE token.client_key = client_key.client_key)
/
ALTER TABLE oauth_token ADD CONSTRAINT client_ident_not_null CHECK(client_ident IS NOT NULL)
/
COMMIT
/
