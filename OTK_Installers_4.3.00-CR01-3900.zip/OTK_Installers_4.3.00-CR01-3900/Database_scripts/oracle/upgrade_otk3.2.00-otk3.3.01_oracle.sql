-- CA Technologies
-- Database upgrade schema for OTK 3.3.01
-- 2015/1
--

-- Updating the version to otk3.3.01
--
UPDATE otk_version SET current_version='otk3.3.01'
/
-- Add new columns to tables
--
ALTER TABLE oauth_client
	ADD custom CLOB null
/
ALTER TABLE oauth_client_key
	ADD (custom CLOB null,
		serviceIds varchar(256) null,
		accountPlanMappingIds varchar(256) null)
/
ALTER TABLE oauth_token
	ADD custom CLOB null
/
ALTER TABLE oauth_initiate
	ADD custom CLOB null
/
-- Add IDX to oauth_client_key
CREATE INDEX ock_idx_clientident ON oauth_client_key(client_ident)
/
-- Add IDX for oauth_token.client_key
CREATE INDEX oat_idx_client ON oauth_token(client_key)
/
-- Add IDX for oauth_token.resource_owner
CREATE INDEX oat_idx_rowner ON oauth_token(resource_owner)
/
-- Add IDX to oauth_id_token.expiration. This will improve the overall performance. Used for deleting expired id_token
CREATE INDEX oaidt_idx_expiration ON oauth_id_token (expiration)
/
CREATE INDEX oaidt_idx_azp ON oauth_id_token (azp)
/
COMMIT
/