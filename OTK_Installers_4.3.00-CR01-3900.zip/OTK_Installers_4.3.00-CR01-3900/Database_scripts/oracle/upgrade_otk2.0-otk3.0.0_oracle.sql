-- CA Technologies
-- Database upgrade schema for OTK 3.0.0 for Oracle
-- Upgrades otk database schema otk2.0 to otk3.0.0
-- 2015/01/30
--
-- - adding oauth_id_token
-- - update version to otk3.0.0
--
-- This table will contain all id_token
--
CREATE TABLE oauth_id_token (
  resource_owner varchar(128) not null,
  azp varchar(128) not null,
  sub varchar(128) null,
  jwt_id varchar(128) null,
  jwt mediumtext not null,
  salt varchar(128) null,
  shared_secret varchar(128) null,
  shared_secret_type varchar(128) null,
  iss varchar(128) not null,
  expiration bigint not null,
  constraint pk_mag_id_token primary key (resource_owner, azp)
)
/
--
-- Updating the version to otk3.0.0
--
UPDATE otk_version SET current_version='otk3.0.0'
/
COMMIT
/