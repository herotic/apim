-- CA Technologies
-- Database schema for OTK
--
-- This table holds valid client application values as defined when the application was registered
--
CREATE TABLE oauth_client (
  client_ident varchar(255) primary key,
  name varchar(255) not null,
  type varchar(128) DEFAULT 'oob' not null,
  description varchar(256) null,
  organization varchar(128) not null,
  registered_by varchar(128) not null,
  created number DEFAULT 0 not null,
  custom CLOB null,
  constraint uk_oc_name_org unique (name, organization)
)
/

-- add IDX to oauth_client
CREATE INDEX oc_idx_clientname ON oauth_client(name)
/

--
-- This table holds valid client keys
--
CREATE TABLE oauth_client_key (
  client_key varchar(255) primary key,
  secret CLOB not null,
  scope varchar(4000) DEFAULT 'oob' not null,
  callback varchar(2048) DEFAULT 'oob' not null,
  environment varchar(128) DEFAULT 'ALL' not null,
  expiration number DEFAULT 0 not null ,
  status varchar(128) not null,
  created number DEFAULT 0 not null,
  created_by varchar(128) not null,
  client_ident varchar(255) not null,
  client_name varchar(255) not null,
  custom CLOB null,
  serviceIds varchar(256) null,
  accountPlanMappingIds varchar(256) null,
  constraint ock_fk_clientIdent foreign key (client_ident) references oauth_client (client_ident) ON DELETE CASCADE
)
/
-- Add IDX to oauth_client_key
CREATE INDEX ock_idx_clientident ON oauth_client_key(client_ident)
/
-- This table holds access_tokens and refresh_tokens
-- oauth 2.0 = access_token, refresh_token
--
CREATE TABLE oauth_token (
  otk_token_id varchar(128) primary key,
  token varchar(128) unique,
  secret varchar(128) null,
  expiration number not null,
  scope varchar(4000) null,
  resource_owner varchar(128) not null,
  created number DEFAULT 0,
  rtoken varchar(128) null unique,
  rexpiration number DEFAULT 0,
  status varchar(128) not null,
  client_key varchar(255) not null,
  client_name varchar(255) not null,
  client_ident varchar(255) not null,
  custom CLOB null
)
/
-- Adding an index
CREATE INDEX oat_idx_expiration ON oauth_token (expiration)
/
CREATE INDEX oat_idx_rowner_client ON oauth_token(resource_owner,client_key)
/
CREATE INDEX oat_idx_rowner ON oauth_token(resource_owner)
/
CREATE INDEX oat_idx_client ON oauth_token(client_key)
/
CREATE INDEX oat_idx_rowner_client_ident ON oauth_token(resource_owner, client_ident)
/
--
-- This table holds temporary tokens
-- oauth 2.0 = authorization_code
--
CREATE TABLE oauth_initiate (
  token varchar(128) primary key,
  secret varchar(128) null,
  expiration number DEFAULT 0 not null,
  scope varchar(4000) null,
  resource_owner varchar(128) null,
  created number DEFAULT 0,
  verifier varchar(128) null,
  callback varchar(256) null,
  client_key varchar(255) not null,
  client_name varchar(255) not null,
  custom CLOB null
)
/
--
-- This table holds session info
--
CREATE TABLE oauth_session (
  session_key varchar(128) not null,
  session_group varchar(128) not null,
  expiration number not null,
  value CLOB not null,
  primary key (session_key, session_group)
)
/
CREATE TABLE otk_version (
   current_version char(10) not null
)
/
INSERT INTO otk_version (current_version) VALUES ('otk4.3.00')
/
--
-- This table will contain all id_token
--
CREATE TABLE oauth_id_token (
  resource_owner varchar(128) not null,
  azp varchar(255) not null,
  sub varchar(255) null,
  jwt_id varchar(512) null,
  jwt CLOB not null,
  salt varchar(384) null,
  shared_secret CLOB null,
  shared_secret_type varchar(128) null,
  iss varchar(255) not null,
  expiration number not null,
  constraint pk_mag_id_token primary key (resource_owner, azp)
)
/
-- Adding indexes to oauth_id_token. This will improve the overall performance
CREATE INDEX oaidt_idx_expiration ON oauth_id_token (expiration)
/
CREATE INDEX oaidt_idx_azp ON oauth_id_token (azp)
/
--
-- CA API Portal API Keys
--
CREATE TABLE portal_apikey (
  apikey_pk varchar(255) primary key,
  apikey varchar(255) unique not null,
  apikey_secret varchar(255) not null,
  status varchar(100) not null,
  organization_id varchar(128) not null,
  organization varchar(255) not null,
  label varchar(255) not null,
  created_by varchar(128) not null,
  modified_by varchar(128) not null,
  created number DEFAULT 0 not null,
  updated number DEFAULT 0 not null,
  apis CLOB null,
  value_xml CLOB not null
)
/
CREATE INDEX papikey_updated ON portal_apikey (updated)
/
--
-- Delete the existing test clients to install them
--
delete from oauth_client where client_ident = '123456800-otk'
/
delete from oauth_client_key where client_ident = '123456800-otk'
/
delete from oauth_client where client_ident = '123456801-otk'
/
delete from oauth_client_key where client_ident = '123456801-otk'
/
delete from oauth_client where client_ident = 'TestClient2.0'
/
delete from oauth_client_key where client_ident = 'TestClient2.0'
/
--
-- OpenID Connect Client for the Basic Client Profile specification
--
insert into oauth_client (client_ident, name, description, organization, registered_by, type)
values ('123456800-otk', 'OpenID Connect Basic Client Profile', 'Test for OpenID Connect BCP', 'CA Technologies Inc.', 'admin', 'confidential')
/
insert into oauth_client_key (client_key, secret, status, created_by, client_ident, client_name, callback, scope)
values ('5eed868e-7ad0-4172-88f2-704bcf78b61e', '2054e4d7-77f2-46c9-bc4d-11a47255a6ec', 'ENABLED', 'admin', '123456800-otk', 'OpenID Connect Basic Client Profile', 'YOUR_SSG/oauth/v2/client/bcp?auth=done', 'openid email profile phone address')
/
--
-- OpenID Connect Client for the Implicit Client Profile specification
--
insert into oauth_client (client_ident, name, description, organization, registered_by, type)
values ('123456801-otk', 'OpenID Connect Implicit Client Profile', 'Test for OpenID Connect ICP', 'CA Technologies Inc.', 'admin', 'public')
/
insert into oauth_client_key (client_key, secret, status, created_by, client_ident, client_name, callback, scope)
values ('5edc4a38-75ec-4617-8854-1a71ff1e0a2e', '5005a669-0295-4602-be7d-6a75342db6d8', 'ENABLED', 'admin', '123456801-otk', 'OpenID Connect Implicit Client Profile', 'YOUR_SSG/oauth/v2/client/icp?auth=done', 'openid email profile phone address')
/
--
-- Create an OAuth 2.0 client
--
INSERT INTO oauth_client (client_ident, name, description, organization, registered_by, type)
VALUES ('TestClient2.0', 'OAuth2Client', 'OAuth 2.0 test client hosted on the ssg', 'CA Technologies Inc.', 'OTK Installer', 'confidential')
/
INSERT INTO oauth_client_key (client_key, secret, status, created_by, client_ident, client_name, callback)
VALUES ('54f0c455-4d80-421f-82ca-9194df24859d', 'a0f2742f-31c7-436f-9802-b7015b8fd8e6', 'ENABLED', 'OTK Installer', 'TestClient2.0', 'OAuth2Client', 'YOUR_SSG/oauth/v2/client/authcode,YOUR_SSG/oauth/v2/client/implicit')
/
--
-- Swagger OAuth2 Client
--
INSERT INTO oauth_client (client_ident, name, description, organization, registered_by, type, custom)
VALUES ('2dc86f35-773c-47e2-958f-3f4bdfc5ea3a', 'Swagger OAuth2 Client', 'Swagger API testing', 'CA Technologies Inc.', 'admin', 'public', '{}')
/
INSERT INTO oauth_client_key (client_key, secret, status, created_by, client_ident, client_name, callback, scope, custom)
VALUES ('2dc86f35-773c-47e2-958f-3f4bdfc5ea3a', '6aa6b190-056d-4a80-8604-79d9e44896ef', 'ENABLED', 'admin', '2dc86f35-773c-47e2-958f-3f4bdfc5ea3a', 'Swagger OAuth2 Client', 'YOUR_SWAGGER_SERVER/oauth2-redirect.html', 'openid email profile phone address', '{
    "openid_registration": {
        "request": {},
        "response": {
            "client_id": "2dc86f35-773c-47e2-958f-3f4bdfc5ea3a",
            "client_secret": "6aa6b190-056d-4a80-8604-79d9e44896ef",
            "client_secret_expires_at": "0",
            "client_id_issued_at": 0,
            "registration_access_token": "",
            "registration_client_uri": "",
            "token_endpoint_auth_method": "client_secret_basic",
            "token_endpoint_auth_signing_alg": "",
            "application_type": "",
            "redirect_uris": [
                "YOUR_SWAGGER_SERVER/oauth2-redirect.html"
            ],
            "client_name": "Swagger OAuth2 Client",
            "subject_type": "pairwise",
            "sector_identifier_uri": "",
            "contacts": [],
            "response_types": [
                "code",
                "implicit",
                "token"
            ],
            "grant_types": [],
            "id_token_signed_response_alg": "HS256",
            "userinfo_signed_response_alg": "",
            "environment": "ALL",
            "organization": "CA Technologies Inc.",
            "master": false,
            "description": "Swagger API testing",
            "scope": "openid email profile phone address",
            "jwks": "",
            "jwks_uri": ""
        }
    }
}')
/
COMMIT
/
